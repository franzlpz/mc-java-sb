export class Medico {
    idMedico : number;
    nombres: string;
    apellidos: string;
    cmp: string;
    fotoUrl: string;
}